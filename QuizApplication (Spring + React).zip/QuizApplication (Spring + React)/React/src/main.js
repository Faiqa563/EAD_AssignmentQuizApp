
import './App.css';
import React from 'react';
import App from './App';
function Main() {
  return (
    <div className="App">
    <App />
    </div>
  );
}

export default Main;