package com.example.demoControllerRepoz;

public interface MyQuiz {

}
